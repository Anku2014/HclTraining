var successtext = "Event Name added successfuly";
var events = new Array();
var failtext = "Event Name already exists ! Please try another one";
var text;

function clear(){
    text = "";
    document.getElementById("successMessage").innerHTML = text;
    document.getElementById("eventName").value = "";
}
function addEvent(){
    var eventname = document.getElementById("eventName").value;
    console.log(eventname);
    if (events.indexOf(eventname) == -1){
        text = successtext;
        document.getElementById("successMessage").innerHTML = text;
        events.push(eventname);
        setTimeout(clear, 2000);
    } else {
        text = failtext;
        document.getElementById("successMessage").innerHTML = text;
        setTimeout(clear, 2000);
    }
}


function displayEvent(){
    var html = "<table> <tr><td>Events Name</td></tr>";
    for(var i=0; i<events.length; i++){
        html += "<tr><td>" + events[i] + "</td></tr>";
        console.log(events[i]);
    }
    html += "</table>";
    document.getElementById("result").innerHTML = html;
}


