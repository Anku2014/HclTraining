var eventId = new Array();
var eventName = new Array();
var price = new Array();
var quantity = new Array();



function add(){
    var id = document.getElementById("eventId").value;
    var name = document.getElementById("eventName").value;
    var cost = document.getElementById("price").value;
    
    eventId.push(id);
    eventName.push(name);
    price.push(cost);
    quantity.push(1);
    display();
}

function display(){
    var sum=0;
    var html = "<table><thead><tr><th>Id</th><th>Product Name</th><th>Price</th><th>Quantity</th><th>Remove from Cart</th></tr></thead><tbody>";
    for(var i=0; i<eventId.length; i++){
        var tprice = price[i]*quantity[i];
        sum += tprice;
        html += "<tr><td>" + eventId[i] + "</td>";
        html += "<td>" + eventName[i] + "</td>";
        html += "<td>" + tprice + "</td>";
        html += "<td>" + "<div><div id = \"select" + i + "\" >"+ quantity[i] +"<button onclick=\"plus("+i+")\">+</button><button onclick=\"minus("+i+")\">-</button></div> </div> </td>";
        html += "<td>" + "<a id=\"remove"+i+"\" onclick=\"remove("+i+")\" href=\"#\"> Remove </a>" + "</td></tr>";
    }
    html += "</tbody></table>";
    html += "<div>Total Cost is "+ sum +"</div>"
    document.getElementById("result").innerHTML = html;
}


function plus(a){
    quantity[a] += 1;
    display();
}

function minus(a){
    if(quantity[a]>1){
        quantity[a] -= 1;
        display();
    }
}
function remove(i){
    eventId.splice(i, 1);
    console.log(eventId);
    eventName.splice(i, 1);
    price.splice(i, 1);
    quantity.splice(i, 1);
    display();
}