var eventName=[];
var success="Event added successfully";
var fail="Event already Exist";
var text="";

function addEvent(){
    var event=document.getElementById("eventName").value;
    if(search(eventName,event))
    {
        document.getElementById("result").innerHTML = fail;
    } else {
        document.getElementById("result").innerHTML = success;
        eventName.push(event);
    }
}
function search(array,value){
array.forEach(element => {
    if(value==element)
    {
        return true;
    }    
});
return false;

}
function displayEvent() {
    eventName.sort();

    var html = "<table> <tr><td>Events Name</td></tr>";
    for(var i=0; i<eventName.length; i++){
        html += "<tr><td>" + eventName[i] + "</td></tr>";
        console.log(eventName[i]);
    }
    html += "</table>";
    document.getElementById("result").innerHTML = html;
}