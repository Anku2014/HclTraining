
public class Main {

	public static void main(String[] args) {
		Venue a= new Venue("Chennai","M.A. Chidambaram Stadium");
		a.print();
	}

}
