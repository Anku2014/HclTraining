public class Venue {
 
	String city;
	String name;
	
	Venue(String city, String name)
	{
		this.city=city;
		this.name=name;
	}
	void print()
	{
		System.out.println("Enter the city name:\n"+city);
		System.out.println("Enter the venue name:\n"+name);
		System.out.println("Venue Details");
		System.out.println("Venue name:"+name);
		System.out.println("City name:"+city);
	}
}
