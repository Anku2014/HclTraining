package LandK;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		int product_code;
		String product_name;
		double price;
		int stock;
		Product p1=new Product();
		p1.setProduct_code(1);
		p1.setProduct_name("mobile");
		p1.setPrice(10000.0);
		p1.setStock(10);
		Product p2=new Product();
		p2.setProduct_code(2);
		p2.setProduct_name("tv");
		p2.setPrice(20000.0);
		p2.setStock(20);
		System.out.println("Product Details:");
	    System.out.println("Product Code:\t"+p1.getProduct_code());
	    System.out.println("Name:\t"+p1.getProduct_name());
	    System.out.println("Price:\t"+p1.getPrice());
	    System.out.println("Stock:\t"+p1.getStock());
	    System.out.println("Product Code:\t"+p2.getProduct_code());
	    System.out.println("Name:\t"+p2.getProduct_name());
	    System.out.println("Price:\t"+p2.getPrice());
	    System.out.println("Stock:\t"+p2.getStock());
	    Product.checkPrice(p1, p2);
	}

}
