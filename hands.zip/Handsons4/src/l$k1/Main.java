package l$k1;
import java.util.*;

import LandK.Product;
public class Main {

	public static void main(String[] args) {
		int product_code;
		String product_name;
		double price;
		int stock;
		Scanner sc=new Scanner(System.in);
		Product p1=new Product();
		System.out.println("Enter Product code:");
		product_code=sc.nextInt();
		p1.setProduct_code(product_code);
		sc.nextLine();
		System.out.println("Enter Product Name:");
		product_name=sc.next();
		p1.setProduct_name(product_name);
		sc.nextLine();
		System.out.println("Enter price:");
		price=sc.nextDouble();
		p1.setPrice(price);
		sc.nextLine();
		System.out.println("Enter Stock");
		stock=sc.nextInt();
		p1.setStock(stock);
		sc.nextLine();
		Product p2=new Product();
		System.out.println("Enter Product code:");
		product_code=sc.nextInt();
		p2.setProduct_code(product_code);
		sc.nextLine();
		System.out.println("Enter Product Name:");
		product_name=sc.next();
		p2.setProduct_name(product_name);
		sc.nextLine();
		System.out.println("Enter price:");
		price=sc.nextDouble();
		p2.setPrice(price);
		sc.nextLine();
		System.out.println("Enter Stock");
		stock=sc.nextInt();
		p2.setStock(stock);
		sc.nextLine();
		System.out.println("Product Details:");
		System.out.println("L $ K Suppliers");
	    System.out.println("Product Code:\t"+p1.getProduct_code());
	    System.out.println("Name:\t"+p1.getProduct_name());
	    System.out.println("Price:\t"+p1.getPrice());
	    System.out.println("Stock:\t"+p1.getStock());
	    p1.discountedPrice();
	    System.out.println("L $ K Suppliers");
	    System.out.println("Product Code:\t"+p2.getProduct_code());
	    System.out.println("Name:\t"+p2.getProduct_name());
	    System.out.println("Price:\t"+p2.getPrice());
	    System.out.println("Stock:\t"+p2.getStock());
	    p2.discountedPrice();
	    Product.checkPrice(p1, p2);
		
	}

}
