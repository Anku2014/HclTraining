package l$k1;

public class Product {
	private int product_code;
	private String product_name;
	private double price;
	private int stock;
	double price1;
	public Product()
	{
		
	}
	public int getProduct_code() {
		return product_code;
	}
	public void setProduct_code(int product_code) {
		this.product_code = product_code;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public static void checkPrice(Product p1,Product p2)
	{
		if(p1.price>p2.price)
			System.out.println(p2.product_name+" "+" is cheaper than "+" "+p1.product_name);
		else
			System.out.println(p1.product_name+" "+"is cheaper than"+" "+p2.product_name);
	}
	public void discountedPrice()
	{
		if(price>=80000)
		{
			price1=price*30/100;
			System.out.println("Discounted Price:" +price1);
	
		}
		else if(price>=60000 && price<=79999)
		{
			price1=price*20/100;
			System.out.println("Discounted Price:" +price1);
			
			
		}
		else if(price>=50000 && price<=59999)
		{
			price1=price*10/100;
			System.out.println("Discounted Price:" +price1);
			
			
		}
		else(price<50000)
		{
			price1=price*5/100;
			System.out.println("Discounted Price:" +price1);
				
		}
	
}
}
