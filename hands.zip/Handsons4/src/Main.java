import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the player details");
		String str=sc.next();
		String words[]=str.split(",");
		String name=words[0];
		String country=words[1];
		String skill=words[2];
		Player p=new Player(name,country,skill);
		p.display();

	}

}
