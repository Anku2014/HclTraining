
public class Venue {
	private String name;
	private String city;
	public Venue(String name,String city)
	 {
		 this.name=name;
		 this.city=city;
	 }
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	 void display()
	 {
		 System.out.println("Venue Details");
		 System.out.println("Venue name:" +getName());
		 System.out.println("City Name:" +getCity());
		 
	 }

}
