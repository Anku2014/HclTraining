import java.util.*;
public class Main {

	public static void main(String[] args) {
		String name;
		String city;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the venue name");
		name=sc.next();
		sc.nextLine();
		System.out.println("Enter the city name");
		city=sc.next();
		Venue a=new Venue(name,city);
		a.display();
		System.out.println("Verify and Update Venue Details");
		System.out.println("Menu");
		System.out.println("1.Update Venue Name");
		System.out.println("2.Update City Name");
		System.out.println("3.All information Correct");
		System.out.println("Type 1 or 2 or 3");
		int i = sc.nextInt();
		switch(i)
		{
			case 1:
				System.out.println("Enter the venue name:");
				name=sc.next();
				a.display();
				break;
		
		   case 2:
			   System.out.println("Enter the city name:");
			   city=sc.next();
			   a.display();
			   break;
			  
		   case 3:
			   a.display();
			   break;
			
		   default:
			   System.out.println("no action needed");
			   break;

	}

}
}
