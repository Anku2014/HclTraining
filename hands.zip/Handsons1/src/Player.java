public class Player {
	String name;
	String country;
	String skill;
	
	Player(String name,String country,String skill)
	{
		this.name=name;
		this.country=country;
		this.skill=skill;
	}
void print()
{
	System.out.println("Enter the player name:\n"+name);
	System.out.println("Enter the country:\n"+country);
	System.out.println("Enter the skill:\n"+skill);
	System.out.println("Player Details");
	System.out.println("Player Name:"+name);
	System.out.println("Player Country:"+country);
	System.out.println("Player Skill:"+skill);
}
}
