
public class Main {

	public static void main(String[] args) {
		Player a= new Player("M.S. Dhoni","India","AllRounder");
		a.print();

	}

}
