package hands1234;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		int number;
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter the venue Details");
	 String name=sc.next();
	 System.out.println("Enter the city name");
	 String city=sc.next();
	 Venue a =new Venue();
	 a.setName(name);
	 a.setCity(city);
	 System.out.println("Venue Details");
	 System.out.println("Venue Name :"+a.getName());
	 System.out.println("City Name:"+a.getName());
	 do{
		 System.out.println("Verigy and Update Venue Details");
		 System.out.println("Menu");
		 System.out.println("1. Update Venue Name");
		 System.out.println("2. Update City Name");
		 System.out.println("3. All informations Correct/Exit");
		 System.out.println("Type 1 or 2 or 3");
		 number=sc.nextInt();
		 if(number==1)
		 {
			 System.out.println("Enter the venue name");
			 name=sc.next();
			 a.setName(name);
			 System.out.println("Venue Details:");
			 System.out.println("Venue Name:" +a.getName());
			 System.out.println("City Name:" +a.getCity());
		 }
		 else if(number==2)
		 {
			 System.out.println("Enter the city name");
			 city=sc.next();
			 a.setCity(city);
			 System.out.println("Venue Details:");
			 System.out.println("Venue Name:" +a.getName());
			 System.out.println("City Name:" +a.getCity());
		 }
		 else if(number==3)
		 {
			 System.out.println("Venue Details:");
			 System.out.println("Venue Name:" +a.getName());
			 System.out.println("City Name:" +a.getCity());
			 break;
		 }
	 }
	 while(number<=3);
	 }

}
