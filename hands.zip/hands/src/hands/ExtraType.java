package hands;

public class ExtraType {
String name;
long runs;
public ExtraType(String name, long runs) {
	super();
	this.name = name;
	this.runs = runs;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public long getRuns() {
	return runs;
}
public void setRuns(long runs) {
	this.runs = runs;
}
public void display()
{
	System.out.println("ExtraType Details");
	System.out.println("ExtraType:"+getName());
	System.out.println("ExtraType"+getRuns());
	}
}
