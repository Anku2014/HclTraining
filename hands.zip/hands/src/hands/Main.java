package hands;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the ExtraType Details");
		String str=sc.next();
		String words[]=str.split("#");
		String name=words[0];
		long runs=Long.parseLong(words[1]);
		ExtraType a=new ExtraType(name,runs);
		a.display();
	}

}
