package hands03;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		long over,ball;
	
		String word[];
		Scanner sc= new Scanner(System.in);
	System.out.println("Enter the number of wickets:");
	int wic=sc.nextInt();
	String str[]=new String[wic];
	for(int i=0;i<wic;i++)
	{
		System.out.println("Enter the details of wicket " +(i+1));
		 str[i]=sc.next();
		 sc.nextLine();
	}
	Wicket a= new Wicket();
	for(int i=0;i<wic;i++)
	{
	word=str[i].split(",");
	over=Long.parseLong(word[0]);
	ball=Long.parseLong(word[1]);
	String wicketType=word[2];
	String playerName=word[3];
	String bowlerName=word[4];
	a.setOver(over);
	a.setBall(ball);
	a.setWicketType(wicketType);
	a.setPlayerName(playerName);
	a.setBowlerName(bowlerName);
	System.out.println("Wicket Details");
	System.out.println("Over:" +a.getOver());
	System.out.println("Ball:" +a.getBall());
	System.out.println("Wicket Type:" +a.getWicketType());
	System.out.println("Player Name:" +a.getPlayerName());
	System.out.println("Bowler Name:" +a.getBowlerName());
	
	}
	
	
	}

}
