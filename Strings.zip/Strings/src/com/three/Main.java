package com.three;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter humpty Sentense:");
		 String str=sc.nextLine();
		 CheckStrin c=new CheckStrin();
		 c.reverseString(str);

	}

}
