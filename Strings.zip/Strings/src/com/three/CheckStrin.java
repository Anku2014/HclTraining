package com.three;

public class CheckStrin {
public CheckStrin()
{
	
}
public String reverseString(String s1)
{
	StringBuilder sb=new StringBuilder(s1);  
    sb.reverse();  
    System.out.println("Dumpty Says,"+sb);
    return sb.toString();
}
}
