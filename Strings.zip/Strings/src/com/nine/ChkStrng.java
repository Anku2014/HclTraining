package com.nine;

public class ChkStrng {
public ChkStrng()
{
	
}
public void checkUp(String str)
{
	if( str.equals(str.toUpperCase()) )
        System.out.println("True");
    else
        System.out.println("False");
    
}
}

