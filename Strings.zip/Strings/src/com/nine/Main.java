package com.nine;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Humpty Sentense :");
		String str=sc.next();
		ChkStrng c=new ChkStrng();
		c.checkUp(str);
	}

}
