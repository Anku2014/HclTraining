package com.one;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter humpty's Sentense:");
		String str=sc.nextLine();
		System.out.println("Enter Dumpty's Sentense:");
		String str1=sc.nextLine();
		CheckStrings c=new CheckStrings();
		c.concatString(str,str1);
	}
	

}
