package com.one;

public class CheckStrings {
public CheckStrings()
{
	
}
public String concatString(String s1,String s2)
{
	String s3;
	s3=s1.concat(s2);
	System.out.println("Concated String:"+s3);
	return s3;
}
}
