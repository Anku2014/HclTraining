package com.seven;

public class ChkStr {
	public ChkStr()
	{
		
	}
public void checkWords(String s1,String s2)
{
	
	if(s1.length()==s2.length())
	{
		System.out.println("Both used the equal no. of words");
	}else if(s1.length()>s2.length())
	{
		System.out.println("Humpty used more words");
	}else
	{
		System.out.println("Dumpty used more words");
		
	}
	
}
}
