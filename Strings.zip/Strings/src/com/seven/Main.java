package com.seven;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter humpty statement :");
		String str=sc.nextLine();
		System.out.println("Enter dumpty sentense :");
		String str1=sc.nextLine();
		ChkStr c=new ChkStr();
		c.checkWords(str, str1);
	}

}
