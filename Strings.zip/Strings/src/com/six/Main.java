package com.six;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Humpty's Sentense :");
		String str=sc.nextLine();
		System.out.println("What Dumpty want to insert and where ?");
		String str1=sc.nextLine();
		System.out.println("Enter Position :");
		int n=sc.nextInt();
		sc.nextLine();
		CheckStr c=new CheckStr();
		c.insertData(str, str1, n);

	}

}
