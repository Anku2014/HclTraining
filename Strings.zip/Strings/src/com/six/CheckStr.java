package com.six;

public class CheckStr {
	public CheckStr()
	{
		
	}
public String insertData(String s1,String s2,int n)
{
	StringBuilder sb=new StringBuilder(s1);  
	sb.insert(11,s2);
	System.out.println("Humpty's New Sentense :"+sb);
	return sb.toString();
}
}
