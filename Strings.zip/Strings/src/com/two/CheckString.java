package com.two;

public class CheckString {
public CheckString()
{
	
}
public boolean stringFound(String s1,String s2)
{
	boolean s;
	if(s=s1.contains(s2))
	System.out.println("Found");
	else
		System.out.println("Not Found");
	return s;
}
}
