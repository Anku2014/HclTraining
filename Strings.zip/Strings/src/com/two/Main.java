package com.two;
import java.util.*;

import com.one.CheckStrings;;
public class Main {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter humpty's Sentense:");
	String str=sc.nextLine();
	System.out.println("Enter Dumpty's Sentense:");
	String str1=sc.nextLine();
	CheckString c=new CheckString();
	c.stringFound(str,str1);

	}

}
