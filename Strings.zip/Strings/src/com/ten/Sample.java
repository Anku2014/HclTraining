package com.ten;

public class Sample {
public Sample()
{
	
}
public void display(String s1)
{
	String s3;
	s3=s1.replace("/","-").replace("*","-");
	System.out.print("Date in Correct Format : "+s3);
}
}
