package com.ten;
import java.io.*;
public class Main {

	public static void main(String[] args) throws IOException {
	 BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
	 System.out.println("Enter Date");
	 String str=br.readLine();
	 str.toString();
	 Sample s=new Sample();
	 s.display(str);
	}

}
