package com.eight;
import java.util.*;

import com.nine.ChkStrng;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Humpty Sentense :");
		String str=sc.nextLine();
		ChkString c=new ChkString();
		c.convertStrings(str);
	}

}
