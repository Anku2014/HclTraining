package com.eight;

public class ChkString {
public ChkString()
{
	
}
public String convertStrings(String s1)
{
	String s3;
	s3=s1.toUpperCase();
	System.out.print("Converted String :" +s3);
	return s3;
}
}
