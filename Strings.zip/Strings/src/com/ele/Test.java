package com.ele;

public class Test {
	int userid;
	String street;
	String city;
	String state;
	public Test()
	{
		
	}
	public Test(int userid, String street, String city, String state) {
		super();
		this.userid = userid;
		this.street = street;
		this.city = city;
		this.state = state;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
public void display(String[] str)
{
	String[] result=new String[4];
	result=str;
	System.out.format("%-15s %-15s %-15s%s\n", "User ID","Street","City","State");
	for(int i=0;i<result.length;i++)
	{
		System.out.print(result);
		result.toString();
	}
}
}
