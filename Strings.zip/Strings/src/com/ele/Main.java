package com.ele;
import java.io.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of users");
		int n=Integer.parseInt(br.readLine());
		String[] str=new String[n];
		System.out.println("Enter user address details ");
		for(int i=0;i<n;i++)
		{
			str[i]=br.readLine();
		}
	Test t=new Test();
	t.display(str);
	}

}
