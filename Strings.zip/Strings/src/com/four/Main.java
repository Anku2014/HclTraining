package com.four;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Humpty's Sentense :");
		String str=sc.nextLine();
		System.out.println("Word To Replace :");
		String str1=sc.nextLine();
		System.out.println("Synonym :");
		String str2=sc.nextLine();
		CheckStri c=new CheckStri();
		c.replaceString(str, str1, str2);
	}

}
