package com.four;

public class CheckStri {
	public CheckStri()
	{
		
	}
	public String replaceString(String s1,String s2,String s3)
	{
		String s4;
		s4=s1.replaceFirst(s2, s3);
		System.out.println("Replaced String:"+s4);
		return s4;
	}

}
