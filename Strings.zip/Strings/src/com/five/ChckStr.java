package com.five;

public class ChckStr {
	public ChckStr()
	{
		
	}
public String removeString(String s1,String s2)
{
	String s3;
	s3=s1.replaceAll(s2,"");
	System.out.println("Dumpty's New Sentense :"+s3);
	return s3;
}
}
