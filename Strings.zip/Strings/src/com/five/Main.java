package com.five;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Dumpty Says :");
		String str=sc.nextLine();
		System.out.println("What Humpty Want To Remove :");
		String str1=sc.nextLine();
		ChckStr c=new ChckStr();
		c.removeString(str, str1);
	}

}
