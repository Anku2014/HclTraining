

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/Welcome")
public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Welcome() {
        super();
        
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String name=request.getParameter("eventname");
		HttpSession session=request.getSession();
		session.setAttribute("eventname", name);
		pw.println("<form action=\"./Display\" method=\"post\">");
		pw.println("<h1 style=\"text-align:center\">Event Management System</h1>");
		pw.println("<div style=\"text-align:center\">Welcome to this event" +name+ "</div></br>");
		pw.println("<input style='margin-left:45%;' type=\"submit\" value=\"Get details\">");
		pw.println("</form>");
		pw.close();
	}

}
