import java.io.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		int[] info= new int[10];
		System.out.println("Enter any 10 values:");
		for(int i=0;i<10;i++)
		{
			info[i]=Integer.parseInt(br.readLine());
		}
		Arrayoube a=new Arrayoube();
		a.divide(info);

	}

}
