package com.atme;

public class ArithmeticEx {

	public void divide(int[] info, int n)
	{
		try
		{
			for(int i=0;i<info.length;i++)
			{
				System.out.println("Result :" +info[i]/n);
			}
		}catch (ArithmeticException ae)
		{
			System.out.println("Can not divide by zero");
		}
	}
}
