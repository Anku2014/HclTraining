package com.atme;
import java.io.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		int n;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		ArithmeticEx ae= new ArithmeticEx();
		int[] info=new int[10];
		System.out.println("Enter any 10 values :");
		for(int i=0;i<info.length;i++)
		{
			info[i]=Integer.parseInt(br.readLine());
		}
		System.out.println("Enter the Divisor :");
		n=Integer.parseInt(br.readLine());
		ae.divide(info, n);
	}

}
