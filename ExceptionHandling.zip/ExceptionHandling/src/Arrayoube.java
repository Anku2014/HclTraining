
public class Arrayoube {
int i=0, j=10;
public Arrayoube()
{
	
}
public void divide(int info[])
{
	try
	{
		while(i>=0)
		{
			System.out.println(info[i]/j);
			i++;
			j--;
		}
	}
	catch (ArrayIndexOutOfBoundsException out)
	{
		System.out.println("Elements are over");
	}
}
}
