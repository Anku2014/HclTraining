package com.one;

public class ArithExp {
int n;
int cost;
public ArithExp()
{
	
}
public void handle(int cost,int n)
{
	try
	{
	int result;
	result= cost/n;
	System.out.println("Cost per day of the item is :"+result);
	}
	catch (ArithmeticException ae)
	{
		System.out.println("Enter Correct Number");
	}
}
}