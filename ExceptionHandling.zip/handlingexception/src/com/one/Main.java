package com.one;
import java.io.*;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		ArithExp ae=new ArithExp();
		System.out.println("Enter the cost of the item ");
		int cost=Integer.parseInt(br.readLine());
		System.out.println("Enter the value of n");
		int n=Integer.parseInt(br.readLine());
		ae.handle(cost,n);
		

	}

}
