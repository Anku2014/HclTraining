package com.three;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		try
		{
			System.out.println("Enter the integer input");
			int n=sc.nextInt();
			sc.nextLine();
			System.out.println("Entered value :"+n);
		}
		catch (InputMismatchException im)
		{
			System.out.println("java.util.InputMismatchException");
		}
	}

}
