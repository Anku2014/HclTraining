package com.two;
import java.io.*;
public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		try
		{
		System.out.println("Enter the item type details:");
		System.out.println("Enter the name:");
		String name=br.readLine();
		System.out.println("Enter the deposit:");
		double deposit=Double.parseDouble(br.readLine());
		System.out.println("Enter the Cost per day:");
		double costPerDay=Double.parseDouble(br.readLine());
		NumberFor n=new NumberFor(name,deposit,costPerDay);
		n.display();
		}
		catch (NumberFormatException ne)
		{
			System.out.println("NumberFormatException");
		}
	}

}
