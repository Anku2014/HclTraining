

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Validate() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String EventName=request.getParameter("eventname");
		String HallName=request.getParameter("hallname");
		String EventType=request.getParameter("eventtype");
		String Details=request.getParameter("details");
		String StartDate=request.getParameter("startdate");
		String EndDate=request.getParameter("enddate");
		if(EventName==""||HallName==""||EventType==""||Details==""||StartDate==""||EndDate=="") {
			RequestDispatcher rd=request.getRequestDispatcher("./Index");  
			pw.println("<h1>Event Creating</h1>"); 
			if(EventName=="") {
				pw.println("EventName must not beempty <br>");
			}
			if(HallName=="") {
				pw.println("HallName must not be empty <br>");
			}
			if(EventType=="") {
				pw.println("EventType must not be empty <br>");
			}
			if(Details=="") {
				pw.println("Details must not be empty <br>");
			}
			if(StartDate=="") {
				pw.println("StartDate must not be empty <br>");
			}
			if(EndDate=="") {
				pw.println("EndDate must not be empty <br>");
			}
			
			rd.include(request, response); 
		}else {
		pw.println("<h2>Successfully Inserted</h2>");
		pw.println("<h1>Event Created Successfully<h1>");
		pw.println("<h3>Event Details</h3>");
		pw.println("<table border='1'>");
		pw.println("<tr>");
		pw.println("<td>EventName</td>");
	    pw.println("<th>HallName</th>");
	    pw.println("<th>EventType</th>");
		pw.println("<th>Details</th>");
		pw.println("<th>StartDate</th>");
		pw.println("<th>EndDate</th>");
		pw.println("</tr>");
		pw.println("<tr>");
		pw.println("<td>"+EventName+"</td>");
		pw.println("<td>"+HallName+"</td>");
		pw.println("<td>"+EventType+"</td>");
		pw.println("<td>"+Details+"</td>");
		pw.println("<td>"+ StartDate+"</td>");
		pw.println("<td>"+EndDate+"</td>");
		pw.println("</tr>");
		pw.println("</table>");
		pw.close();
	}

	}
}
