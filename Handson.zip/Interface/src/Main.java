import java.io.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		String info;
		String stallName;
		int cost;
		String ownerName;
		int tvSet;
		int screen;
		int projector;
		String[] str=new String[4];
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Choose Stall Type");
		System.out.println("1) Gold Stall");
		System.out.println("2) Premium Stall");
		System.out.println("3) Executive Stall");
		int n=Integer.parseInt(br.readLine());
		switch(n)
		{
		case 1:
		{
			System.out.println("Enter Stall details in comma seperated");
			info=br.readLine();
			str=info.split(",");
			stallName=str[0];
			cost=Integer.parseInt(str[1]);
			ownerName=str[2];
			tvSet=Integer.parseInt(str[3]);
			Stall g=new GoldStall(stallName,cost,ownerName,tvSet);
			g.display();
			break;
		}
		case 2:
		{
			System.out.println("Enter Stall details in comma seperated");
			info=br.readLine();
			str=info.split(",");
			stallName=str[0];
			cost=Integer.parseInt(str[1]);
			ownerName=str[2];
			projector=Integer.parseInt(str[3]);
			Stall p=new PremiumStall(stallName,cost,ownerName,projector);
			p.display();
			break;
		}
		case 3:
		{
			System.out.println("Enter Stall details in comma seperated");
			info=br.readLine();
			str=info.split(",");
			stallName=str[0];
			cost=Integer.parseInt(str[1]);
			ownerName=str[2];
			screen=Integer.parseInt(str[3]);
			Stall e=new ExecutiveStall(stallName,cost,ownerName,screen);
			e.display();
			break;
		}
		default:
			System.out.println("Enter Aprropriate Number");
		}

	}

}
