import java.io.*;
public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("What you want to visit");
		System.out.println("Rajmachi");
		System.out.println("Shivgadh");
		System.out.println("Murud");
		String place=br.readLine();
		Rajmachi r=new Rajmachi();
		Shivgadh s=new Shivgadh();
		Murud m=new Murud();
		if(place=="Rajmachi")
		{
			r.distance();
		}
		else if(place=="Shivgadh")
		{
			s.distance();
		}
		else
		{
			m.distance();
		}
	}

}
