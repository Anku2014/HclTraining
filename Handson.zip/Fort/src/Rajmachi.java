interface Fort
{
	public void distance();
}
public class Rajmachi implements Fort {

public Rajmachi()
{
	
}
public void distance()
{
	System.out.println("You are going to visit Murud");
	System.out.println("The distance is 55 km");
}
}
