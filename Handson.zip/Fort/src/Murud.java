
public class Murud implements Fort {
	public Murud()
	{
		
	}
public void distance()
{
	System.out.println("You are going to visit Murud");
	System.out.println("The distance is 93 km");
}
}
