
public class Shivgadh implements Fort{

public Shivgadh()
{
	
}
public void distance()
{
	System.out.println("you are going to visit Shivgadh");
	System.out.println("The distance is 100 km");
}
}
