
public class Square extends Shape {
	float side;

	public Square(float side) {
		super();
		this.side = side;
	}

	public float getSide() {
		return side;
	}

	public void setSide(float side) {
		this.side = side;
	}

	public double calculatePerimeter() {
		double parameter;
		parameter = 4 * side;
		return parameter;
	}

}
