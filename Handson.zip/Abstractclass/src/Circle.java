
public class Circle extends Shape{
	float radius;
	public Circle()
	{
		
	}
	
	public Circle(float radius) {
		super();
		this.radius = radius;
	}
	public float getRadius() {
		return radius;
	}
	public void setRadius(float radius) {
		this.radius = radius;
	}
	public double calculatePerimeter() {
		double perimeter;
		perimeter=2*3.14*radius;
		return perimeter;
	}

}
