import java.io.*;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		int c;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("List of Shapes:");
		System.out.println("1.Circle");
		System.out.println("2.Rectangle");
		System.out.println("3.Square");
		System.out.println("Enter your choice:");
		c = Integer.parseInt(br.readLine());

		if (c == 1) {
			System.out.println("Enter the radius of the Circle:");
			float radius = Float.parseFloat(br.readLine());
			Shape s = new Circle(radius);
			System.out.println("The perimeter is :" + s.calculatePerimeter());

		} else if (c == 2) {
			System.out.println("Enter the length of Rectangle:");
			float length = Float.parseFloat(br.readLine());
			System.out.println("Enter the Breadth of Rectangle:");
			float breadth = Float.parseFloat(br.readLine());
			Shape q = new Rectangle(length, breadth);
			System.out.println("The perimeter is :" + q.calculatePerimeter());

		} else {
			System.out.println("Enter the Side of Square:");
			float side = Float.parseFloat(br.readLine());
			Shape w = new Square(side);
			System.out.println("The perimeter is :" + w.calculatePerimeter());

		}

	}
}
