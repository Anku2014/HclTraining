
abstract public class Shape {
public abstract double calculatePerimeter();

}
