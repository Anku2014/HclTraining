package com.abc;
import java.io.*;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		 String accName;
		 String accNo;
		 String bankName;
		 String tinNumber;
		 String orgName;
		 String info;
		 String str[]=new String[4];
		 BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		 
		 
		 System.out.println("Choose Account Type");
		 System.out.println("1. Savings Account");
		 System.out.println("2. Current Account");
		 int i=Integer.parseInt(br.readLine());
		 if(i==1)
		 {
		 System.out.println("Enter Account details in comma separated(Account Name,Account Number,Bank Name,Organisational Name)");
		 info=br.readLine();
		 str=info.split(",");
		 accName=str[0];
		 accNo=str[1];
		 bankName=str[2];
		 orgName=str[3];
		 SavingAccount c=new SavingAccount(accName,accNo,bankName,orgName);
		 c.display();
         }
		 if(i==2)
		 {
			 System.out.println("Enter Account details in comma separated(Account Name,Account Number,Bank Name,TIN Number)");
			 info=br.readLine();
			 str=info.split(",");
			 accName=str[0];
			 accNo=str[1];
			 bankName=str[2];
			 tinNumber=str[3];
			 CurrentAccount b=new CurrentAccount(accName,accNo,bankName,tinNumber);
			 b.display();
		 }

}
}