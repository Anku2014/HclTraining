package com.qwe;
import java.io.*;

public class Main {

	public static void main(String[] args) throws IOException {
		String detail;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Account Details:");
		detail=br.readLine();
		AccountBO a=new AccountBO();
		FixedAccount f=a.getAccountDetail(detail);
		System.out.format("%-20s %-10s %-20s %-20s %s\n","Account Number","Balance","Account holder name","Minimum balance","Locking period");
		System.out.format("%-20s %-10s %-20s %-20s %s\n",f.getAccountNumber(),f.getBalance(),f.getAccountHolderName(),f.getMinimumBalance(),f.getLockingPeriod());
	}

}
