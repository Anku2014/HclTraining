package com.qwe;

public class AccountBO {
	 
	public FixedAccount getAccountDetail(String detail)
	{
		String[] info=detail.split(",");
		String[] str=new String[4];
		FixedAccount f=new FixedAccount(info[0],Double.parseDouble(info[1]),info[2],Double.parseDouble(info[3]),Integer.parseInt(info[4]));
		return f;
	}

}
