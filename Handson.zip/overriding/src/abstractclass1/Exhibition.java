package abstractclass1;

public class Exhibition extends Event {
int noOfStall;
public Exhibition()
{
	
}
public Exhibition(int noOfStall) {
	super();
	this.noOfStall = noOfStall;
}
public int getNoOfStall() {
	return noOfStall;
}
public void setNoOfStall(int noOfStall) {
	this.noOfStall = noOfStall;
}
public double projectRevenue()
{
	double revenue;
	revenue=noOfStall*10000;
	return revenue;
}
}
