package abstractclass1;
import java.io.*;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		int c;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
			System.out.println("Enter the name of event:");
			String name=br.readLine();
			System.out.println("Enter the detail of the event:");
			String detail=br.readLine();
			System.out.println("Enter the Owner Name of the event:");
			String ownerName=br.readLine();
			System.out.println("Enter the type of event:");
			System.out.println("1.Exhibition");
			System.out.println("2.StageEvent");
			c=Integer.parseInt(br.readLine());
			if(c==1)
			{
				System.out.println("Enter the number of stalls:");
				int noOfStalls=Integer.parseInt(br.readLine());
				Exhibition e=new Exhibition(noOfStalls);
				System.out.println("The Projected revenue of the event is:"+" "+e.projectRevenue());
			}
			else
			{
				System.out.println("Enter the no of shows:");
				int noOfShows=Integer.parseInt(br.readLine());
				System.out.println("Enter the number of seats per show:");
				int noOfSeatsPerShow=Integer.parseInt(br.readLine());
				StageEvent s=new StageEvent(noOfShows,noOfSeatsPerShow);
				System.out.println("The Projected revenue of the event is:"+" "+s.projectRevenue());;				
			}

	}

}
