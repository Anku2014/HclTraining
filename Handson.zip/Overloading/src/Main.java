import java.io.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the shape:");
		System.out.println("1.Circle");
		System.out.println("2.Rectangle");
		System.out.println("3.Triangle");
		int i=Integer.parseInt(br.readLine());
		switch(i)
		{
		case 1:
		{
			System.out.println("Enter the radius:");
			double radius=Double.parseDouble(br.readLine());
			Circle c=new Circle(radius);
			c.computeArea();
			break;
		}
		case 2:
		{
			System.out.println("Enter the length and breadth");
			double length=Double.parseDouble(br.readLine());
			double breadth=Double.parseDouble(br.readLine());
			Rectangle r=new Rectangle(length,breadth);
			r.computeArea();
			break;
		}
		case 3:
		{
			System.out.println("Enter the base and height");
			double base=Double.parseDouble(br.readLine());
			double height=Double.parseDouble(br.readLine());
			Triangle t=new Triangle(base,height);
			t.computeArea();
			break;
		}
		default:
		{
			System.out.println("select appropriate number");
		}
	}
	}

}
