interface MutualFund
{
	abstract public void duration();
	abstract public void amount();
	
}
public class Axis implements MutualFund{
int amount;
int sip;
public Axis()
{
	
}
public Axis(int amount, int sip) {
	super();
	this.amount = amount;
	this.sip = sip;
}
public int getAmount() {
	return amount;
}
public void setAmount(int amount) {
	this.amount = amount;
}
public int getSip() {
	return sip;
}
public void setSip(int sip) {
	this.sip = sip;
}
public void duration()
{
	System.out.println("Duration is :"+sip+ "years");
}
public void amount()
{
	double sum;
	sum=(amount*56*sip)/100;
	System.out.println("You will have return as "+sum + "in" +sip+ "years");
}
}
