import java.io.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the amount you want to invest");
		int amount=Integer.parseInt(br.readLine());
		System.out.println("Enter the tenure of the SIP");
		int sip=Integer.parseInt(br.readLine());
		Axis a=new Axis(amount,sip);
		Hdfc h=new Hdfc(amount,sip);
		Icici i=new Icici(amount,sip);
		System.out.println("Select the bank:");
		String bank=br.readLine();
		if(bank=="Axisbank")
		{
			a.amount();
		}
		else if(bank=="Hdfc")
		{
			h.amount();
		}
		else
		{
			i.amount();
		}
	}
}
