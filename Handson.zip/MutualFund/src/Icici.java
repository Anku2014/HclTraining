
public class Icici implements MutualFund {
	int amount;
	int sip;
	public Icici()
	{
		
	}
	public Icici(int amount, int sip) {
		super();
		this.amount = amount;
		this.sip = sip;
	}
	public void duration()
	{
		System.out.println("Duration is :"+sip+ "years");
	}
	public void amount()
	{
		double sum;
		sum=(amount*60/100)*sip;
		System.out.println("You will have return as "+sum +"in" +sip+"years");
	}
}
