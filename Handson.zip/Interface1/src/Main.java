import java.io.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Breadth & Length of Rectangle :");
		double length=Double.parseDouble(br.readLine());
		double breadth=Double.parseDouble(br.readLine());
		System.out.println("Enter Side value");
		double side=Double.parseDouble(br.readLine());
		Rectangle s=new Rectangle(length,breadth);
		Square r=new Square(side);
		System.out.println("Perimeter of Rectangle :"+s.calcPeri());
		System.out.println("Area of Rectangle :"+s.calcArea());
		System.out.println("Perimeter of Square :"+r.calcPeri());
		System.out.println("Area of Square :"+r.calcArea());
	}

}
