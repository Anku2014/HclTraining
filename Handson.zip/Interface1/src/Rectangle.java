
public class Rectangle implements Polygon {
double length;
double breadth;
public Rectangle()
{
	
}
public Rectangle(double length, double breadth) {
	super();
	this.length = length;
	this.breadth = breadth;
}
public double getLength() {
	return length;
}
public void setLength(double length) {
	this.length = length;
}
public double getBreadth() {
	return breadth;
}
public void setBreadth(double breadth) {
	this.breadth = breadth;
}
public double calcPeri()
{
	double peri;
	peri=2*length*breadth;
	return peri;
}
public double calcArea()
{
	double area;
	area=length*breadth;
	return area;
}
}
