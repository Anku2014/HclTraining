interface Polygon
{
	public double calcPeri();
	public double calcArea();
}
public class Square implements Polygon{
	double side;
	public Square()
	{
		
	}
	
	public Square(double side) {
		super();
		this.side = side;
	}

	public double getSide() {
		return side;
	}

	public void setSide(double side) {
		this.side = side;
	}

	public double calcPeri()
	{
		Double peri;
		peri=4*side;
		return peri;
	}
	public double calcArea()
	{
		double area;
		area=side*side;
		return area;
	}
}
