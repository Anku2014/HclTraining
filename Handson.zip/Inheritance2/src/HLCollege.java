
public class HLCollege {
	String registration_no;
	String name;
	String place;
	String trustee_names;
	int foundation_year;
	public HLCollege()
	{
		
	}
	public HLCollege(String registration_no, String name, String place, String trustee_names, int foundation_year) {
		super();
		this.registration_no = registration_no;
		this.name = name;
		this.place = place;
		this.trustee_names = trustee_names;
		this.foundation_year = foundation_year;
	}
	public String getRegistration_no() {
		return registration_no;
	}
	public void setRegistration_no(String registration_no) {
		this.registration_no = registration_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getTrustee_names() {
		return trustee_names;
	}
	public void setTrustee_names(String trustee_names) {
		this.trustee_names= trustee_names;
	}
	public int getFoundation_year() {
		return foundation_year;
	}
	public void setFoundation_year(int foundation_year) {
		this.foundation_year = foundation_year;
	}
	public void shoowCollegeInfo()
	{
		System.out.println("College registation number:"+registration_no);
		System.out.println("College name:"+name);
		System.out.println("College Address:"+place);
		System.out.println("Trustees Name:"+trustee_names);
	}

}
