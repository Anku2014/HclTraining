
public class Engineering extends HLCollege {
	String building_name;
	int no_of_branches;
	public Engineering()
	{
		
	}
	public Engineering(String building_name, int no_of_branches) {
		super();
		this.building_name = building_name;
		this.no_of_branches = no_of_branches;
	}
	public String getBuilding_name() {
		return building_name;
	}
	public void setBuilding_name(String building_name) {
		this.building_name = building_name;
	}
	public int getNo_of_branches() {
		return no_of_branches;
	}
	public void setNo_of_branches(int no_of_branches) {
		this.no_of_branches = no_of_branches;
	}
	public void showBranchDetails()
	{
		System.out.println("Enter Building Name:"+building_name);
		System.out.println("Enter the number of branches:"+no_of_branches);
	}

}
