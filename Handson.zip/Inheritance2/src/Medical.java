
public class Medical extends HLCollege {
String building_name;
int no_of_branches;
boolean attached_hospital;
public Medical()
{
	
}
public Medical(String building_name, int no_of_branches, boolean attached_hospital) {
	super();
	this.building_name = building_name;
	this.no_of_branches = no_of_branches;
	this.attached_hospital = attached_hospital;
}
public String getBuilding_name() {
	return building_name;
}
public void setBuilding_name(String building_name) {
	this.building_name = building_name;
}
public int getNo_of_branches() {
	return no_of_branches;
}
public void setNo_of_branches(int no_of_branches) {
	this.no_of_branches = no_of_branches;
}
public boolean isAttached_hospital() {
	return attached_hospital;
}
public void setAttached_hospital(boolean attached_hospital) {
	this.attached_hospital = attached_hospital;
}
public void showBranchDetails()
{
	System.out.println("Enter the building name:"+building_name);
	System.out.println("Enter the Number of branches:"+no_of_branches);
	System.out.println("College has hospital ?"+attached_hospital);
	
}
}
