import java.io.*;
public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Stall obj=new Stall();
		System.out.println("Enter the name of stall:");
		String name=br.readLine();
		System.out.println("Enter the detail of the stall:");
		String detail=br.readLine();
		System.out.println("Enter the owner name of the stall:");
		String ownerName=br.readLine();
		System.out.println("Enter the type of stall:");
		String stallType=br.readLine();
		System.out.println("Enter the size of stall in square feet:");
		int squareFeet=Integer.parseInt(br.readLine());
		System.out.println("Does the room have TV(y/n)");
		String tv=br.readLine();
		if(tv=="y")
		{
			System.out.println("Enter the Number of Tv:");
			int numberOfTv=Integer.parseInt(br.readLine());
			double cost=obj.computeCost(stallType, squareFeet, numberOfTv);
			System.out.println("The cost of Computation:\t"+cost);
		}
		else
		{
			double cost=obj.computeCost(stallType, squareFeet);
			System.out.println("The cost of Computation:\t"+cost);
		}
		
	}

}
