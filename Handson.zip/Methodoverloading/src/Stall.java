
public class Stall {
protected String name;
protected String details;
protected String ownerName;
public Stall()
{
	super();
}
public Stall(String name, String details, String ownerName) {
	super();
	this.name = name;
	this.details = details;
	this.ownerName = ownerName;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDetails() {
	return details;
}
public void setDetails(String details) {
	this.details = details;
}
public String getOwnerName() {
	return ownerName;
}
public void setOwnerName(String ownerName) {
	this.ownerName = ownerName;
}
public double computeCost(String stallType, int squareFeet)
{
	double cost;;
	if(stallType=="Platinum")
	{
		cost=200*squareFeet;
		return cost;
	}
	else if(stallType=="Diamond")
	{
		cost=150*squareFeet;
		return cost;
	}
	else 
	{
		cost=100*squareFeet;
		return cost;
	}
}
public double computeCost(String stallType,int squareFeet,int numberOfTv)
{
	double cost;
	if(stallType=="Platinum")
	{
		cost=200*squareFeet+numberOfTv*10000;
		return cost;
	}
	else if(stallType=="Diamond")
	{
		cost=150*squareFeet+numberOfTv*10000;
		return cost;
	}
	else
	{
		cost=100*squareFeet+numberOfTv*10000;
		return cost;
	}
	
}

}
