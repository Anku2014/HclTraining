import java.util.*;
public class Main {

	
		static int product_code;
		static String product_name;
		static double price;
		static int stock;
		public static void buildProduct()
		{
			Scanner sc=new Scanner(System.in);
			Product p=new Product();
		    Product[] str=new Product[5];
		for(int i=0;i<5;i++)
		{
			System.out.println("Enter Product code");
			product_code=sc.nextInt();
			sc.nextLine();
			System.out.println("Enter Product Name");
			product_name=sc.next();
			sc.nextLine();
			System.out.println("Enter Price");
			price=sc.nextDouble();
			sc.nextLine();
			System.out.println("Enter Stock");
			stock=sc.nextInt();
			sc.nextLine();
			str[i]=new Product(product_code,product_name,price,stock);
			str[i].setProduct_code(product_code);
			str[i].setProduct_name(product_name);
			str[i].setPrice(price);
			str[i].setStock(stock);
		}
		System.out.println("Product Details :");
		System.out.println("L & K Suppliers");
		for(int i=0;i<5;i++)
		{
			System.out.println("Product Code:\t" +str[i].getProduct_name());
			System.out.println("Name:\t" +str[i].getProduct_name());
			System.out.println("Stock:\t" +str[i].getStock());
			System.out.println("Price:\t" +str[i].getPrice());
			str[i].getDiscountedPrice();
		}
		System.out.println("The Product With Min Stock");
		

		Product p1=p.checkLessStock(str);
		System.out.println("L & k Suppliers");
		System.out.println("Name:\t"+p.getProduct_name());
		System.out.println("Stock:\t"+p.getStock());
		
		}
public static void main(String args[])
{
	buildProduct();
}
	

}
