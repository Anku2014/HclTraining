package com.lkj;
import java.util.*;
import java.io.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		List<String> l=new ArrayList<String>();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of Customers:");
		int n=Integer.parseInt(br.readLine());
		System.out.println("Enter the booking price accordingly with customer name in CSV(Customer Name,Price)");
		for(int i=0;i<n;i++)
		{
			String s=br.readLine();
			l.add(s);
		}
	System.out.println("min amount spend by "+Collections.min(l));
	System.out.println("max amount spend by "+Collections.max(l));
	}
	
}
