package com.xvx;
import java.util.*;
import java.io.*;
public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		List<Stall> l=new ArrayList();
		System.out.println("Enter the number of stall details");
		int n=Integer.parseInt(br.readLine());
		
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the stall "+(i+1)+" detail");
			String s=br.readLine();
			String a[]=s.split(",");
			l.add(new Stall(a[0],a[1],a[2],a[3]));
		}
		Iterator<Stall> itr=l.iterator();
		System.out.format("%-15s%-15s%-15s%-15s","Name", "Detail", "Type", "Ownername");
		Stall st=new Stall();
		while(itr.hasNext())
		{
			
			if(itr.next().getName().startsWith("test"))
			{
				itr.remove();
			}else
			{
				st.display();
			}
			
		}
		
		
	}

}
