package com.acb;
import java.io.*;
import java.util.ArrayList;
public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		ArrayList<ItemType> l=new ArrayList<>();
		System.out.println("Enter the details of item type 1");
		System.out.println("Name :");
		String s=br.readLine();
		System.out.println("Deposit :");
		double d=Double.parseDouble(br.readLine());
		System.out.println("Cost Per Day :");
		double d1=Double.parseDouble(br.readLine());
		l.add(new ItemType(s,d,d1));
		String yn;
		int i=2;
		do
		{
			System.out.println("Do you want to continue(y/n)");
			yn=br.readLine();
			if(yn.equals("y"))
			{
			System.out.println("Name :");
			s=br.readLine();
			System.out.println("Deposit :");
			d=Double.parseDouble(br.readLine());
			System.out.println("Cost Per Day :");
			d1=Double.parseDouble(br.readLine());
			l.add(new ItemType(s,d,d1));
			i=i+1;
			}else
			{
				break;
			}
		}while(yn.equals("y"));
		for(ItemType it:l)
		{
			System.out.println(it.toString(it));
		}
	}

}
