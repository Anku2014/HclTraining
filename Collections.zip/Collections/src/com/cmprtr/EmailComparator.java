package com.cmprtr;
import java.util.*;
public class EmailComparator implements Comparator<Cmpr> {

public int compare(Cmpr e1,Cmpr e2)
{
	return e1.getEmail().compareTo(e2.getEmail());
}

}
