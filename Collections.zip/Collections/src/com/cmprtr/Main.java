package com.cmprtr;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		ArrayList<Cmpr> al=new ArrayList<>();
		System.out.println("Enter the Number of users:");
		int n=Integer.parseInt(br.readLine());
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the detail of user "+(i+1));
			String s=br.readLine();
			String a[]=s.split(",");
			al.add(new Cmpr(a[0],a[1],a[2],a[3]));
		}
		System.out.println("Sort by");
		System.out.println("1.Name");
		System.out.println("2.Email");
		int t=Integer.parseInt(br.readLine());
		if(t==1)
		{
			Collections.sort(al, new NameComparator());
			System.out.format("%-15s %-15s %-15s %s\n","Name","Email","Username","Password");
			Iterator<Cmpr> itr=al.iterator();
			Cmpr c=new Cmpr();
			while(itr.hasNext())
			{
				c=itr.next();
				System.out.println(c.getName()+"\t\t"+c.getEmail()+"\t\t"+c.getUsername()+"\t\t"+c.getPassword());
			}
		}
		else
		{
			Collections.sort(al, new EmailComparator());
			System.out.format("%-15s %-15s %-15s %s\n","Name","Email","Username","Password");
			Iterator<Cmpr> itr=al.iterator();
			Cmpr c=new Cmpr();
			while(itr.hasNext())
			{
				c=itr.next();
				System.out.println(c.getName()+"\t\t"+c.getEmail()+"\t\t"+c.getUsername()+"\t\t"+c.getPassword());
			}
		}
		}

}
