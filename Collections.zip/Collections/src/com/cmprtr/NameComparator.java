package com.cmprtr;
import java.util.*;
public class NameComparator implements Comparator<Cmpr> {
	public int compare(Cmpr n1, Cmpr n2) {
		return n1.getName().compareTo(n2.getName());
		
	}
}
