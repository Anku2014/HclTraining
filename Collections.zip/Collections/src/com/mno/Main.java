package com.mno;
import java.io.*;
import java.util.Iterator;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		UserBO u=new UserBO();
		u.addAll(u.userList());
		System.out.println("Enter the no of user to be added");
		int n=Integer.parseInt(br.readLine());
		for(int i=1;i<=n;i++) 
		{
			System.out.println("The details of the User "+i +"are");
			String s=br.readLine();
			String s1[]=s.split(",");
			u.add(new User(s1[0],s1[1],s1[2],s1[3]));
		}
		Iterator<User> itr=u.iterator();
		User u1=new User();
		System.out.format("%-20s%-20s%-20s%-20s","Name","ContactNumber","UserName","Email");
		while(itr.hasNext())
		{
			u1=itr.next();
			u1.display();
		}
		System.out.println("Enter the range of user deatils to be removed");
		int n1=Integer.parseInt(br.readLine());
		int n2=Integer.parseInt(br.readLine());
		u.removeUser(n1, n2);
		Iterator<User> itr1=u.iterator();
		User u2=new User();
		System.out.format("%-20s%-20s%-20s%-20s","Name","ContactNumber","UserName","Email");
		while(itr1.hasNext())
		{
			u2=itr1.next();
			u2.display();
		}
	}

}
