package com.zxc;
import java.io.*;
import java.util.HashSet;
public class Main {

	public static void main(String[] args) throws IOException {
		HashSet<String> set=new HashSet<String>();
		String s;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		do
		{
		System.out.println("Enter the username :");
		set.add(br.readLine());
		System.out.println("Do you want to continue(y/n)");
		s=br.readLine();
		
	}while(s.equals("y"));
		System.out.println("The unique number of username is "+set.size());
}
}
