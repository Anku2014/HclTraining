package com.abc;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String j,a;
		ArrayList<String> l=new ArrayList<>();
		System.out.println("Enter the username 1:");
			j=sc.nextLine();
			l.add(j);
			
			int n=2;
			do
			{
				System.out.println("Do you want to continue(y/n)");
				a=sc.nextLine();
				if(a.equals("y"))
				{
					System.out.println("Enter the username"+n+":");
					String i=sc.nextLine();
					l.add(i);
				}
				else
					break;
			}
			while(a.equals("y"));
			System.out.println("The Names Entered are :");
			for(String b:l)
			{
				System.out.println(b);
			}
	}

}
