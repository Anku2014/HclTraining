package com.qwe;

public class Hall implements Comparable<Hall>{
	private String name;
	private	String contactNumber;
	private	double costperDay;
	private	String ownerName;
	public Hall()
	{
		
	}
	public Hall(String name, String contactNumber, double costperDay, String ownerName) {
		super();
		this.name = name;
		this.contactNumber = contactNumber;
		this.costperDay = costperDay;
		this.ownerName = ownerName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public double getCostperDay() {
		return costperDay;
	}
	public void setCostperDay(double costperDay) {
		this.costperDay = costperDay;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public int compareTo(Hall h)
	{
		double cpd=this.costperDay;
		double cpd2=h.costperDay;
		if(cpd<cpd2)
			return -1;
		else if(cpd>cpd2)
			return 1;
		else
			return 0;
	}
	public String toString()
	{
		System.out.println(" ");
		System.out.format("%-15s%-15s%-15s%-15s",name,contactNumber,costperDay,ownerName);
		return "";
	}
}
