package com.qwe;
import java.util.*;
import java.io.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of halls:");
		int n=Integer.parseInt(br.readLine());
		List<Hall> al=new ArrayList<>();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the details of hall "+(i+1));
			String s=br.readLine();
			String a[]=s.split(",",4);
			al.add(new Hall(a[0],a[1],Double.parseDouble(a[2]),a[3]));
		}
		Collections.sort(al);
		System.out.format("%-15s%-15s%-15s%-15s","name","contactNumber","costperDay","ownerName");
		Iterator<Hall> it=al.iterator();
		Hall hall=new Hall();
		while(it.hasNext())
		{
			hall=it.next();
			System.out.println(hall);
		}
	}

}
