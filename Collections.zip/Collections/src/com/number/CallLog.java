package com.number;

import java.util.TreeSet;

public class CallLog {
	private String name;
private String dialledNumber;
private String duration;
private String dialledDate;
public CallLog()
{
	
}
public CallLog(String name,String dialledNumber, String duration) {
	super();
	this.name=name;
	this.dialledNumber = dialledNumber;
	this.duration = duration;
	
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDialledNumber() {
	return dialledNumber;
}
public void setDialledNumber(String dialledNumber) {
	this.dialledNumber = dialledNumber;
}
public String getDuration() {
	return duration;
}
public void setDuration(String duration) {
	this.duration = duration;
}
public String getDialledDate() {
	return dialledDate;
}
public void setDialledDate(String dialledDate) {
	this.dialledDate = dialledDate;
}
public String toString(CallLog c)
{
	return c.getName()+"(+91-"+c.getDialledNumber()+")\t"+c.getDuration()+" seconds";
}
public static void display(TreeSet<CallLog> c1)
{
	System.out.println("Call-logs");
	System.out.println("CallerName    Duration");
	for(CallLog ca:c1)
	{
		System.out.println(ca.toString(ca));
	}
}
}
