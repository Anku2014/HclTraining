package com.number;
import java.util.TreeSet;
import java.io.*;
public class Main {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		String file="file.txt";
		TreeSet<CallLog> t=new TreeSet<>(new MyComparator());
	    try(BufferedReader br=new BufferedReader(new FileReader(file)))
	    {
	    	String str="";
	    	while((str=br.readLine())!=null)
	    	{
	    		String[] info=str.split(",");
	    		CallLog c1=new CallLog(info[0],info[1],info[2]);
	    		t.add(c1);
	    	}
	    }
	    catch(FileNotFoundException e)
	    {
	    	e.printStackTrace();
	    }
	    CallLog.display(t);
	}

}
