package com.number;

import java.util.Comparator;

public class MyComparator implements Comparator<CallLog> {
	public int compare(CallLog l1, CallLog l2) {
		String s = l1.getName();
		String s1 = l2.getName();
		return s1.compareTo(s);
	}
}
