package com.addresl;
import java.io.*;
import java.util.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
	 ArrayList<Address> al=new ArrayList<>();
	 BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	 System.out.println("Enter the numbers of users :");
	 int n=Integer.parseInt(br.readLine());
	 System.out.println("Enter user address in CSV(Username,AddressLine 1,AddressLine 2,PinCode)");
	 for(int i=0;i<n;i++)
	 {
		 String s=br.readLine();
		 String a[]=s.split(",");
		 al.add(new Address(a[0],a[1],a[2],Integer.parseInt(a[3])));
	 }
	 Collections.sort(al);
	 System.out.println("User Details :");
	 for(Address ad:al)
	 {
		 System.out.println(ad.toString());
	 }
	}

}
