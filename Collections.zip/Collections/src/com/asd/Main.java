package com.asd;
import java.io.*;
import java.util.ArrayList;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		ArrayList<String> al=new ArrayList<String>();
		System.out.println("Enter the number of halls :");
		int h=Integer.parseInt(br.readLine());
		for(int i=0;i<h;i++)
		{
			System.out.println("Enter the Hall Name"+(i+1));
			String j=br.readLine();
			al.add(j);
		}
		System.out.println("Enter the hall to be searched :");
		String s=br.readLine();
		if(al.contains(s))
		{
			System.out.println(s+" "+"hall is found in the list at position "+al.indexOf(s));
		}
	}

}
